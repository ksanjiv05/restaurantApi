let str = "10";
console.log(str);
const num = parseInt(str);
console.log(num * num * num);
